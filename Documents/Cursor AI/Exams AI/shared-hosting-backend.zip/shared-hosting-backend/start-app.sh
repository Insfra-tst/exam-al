#!/bin/bash

# Exam Pattern Analyzer - Startup Script for Elaraix.com
# This script helps you start the Node.js application

echo "🚀 Starting Exam Pattern Analyzer on Elaraix.com..."
echo "📍 Application URL: https://elaraix.com/exam/"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js version 16 or higher."
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 16 ]; then
    echo "❌ Node.js version 16 or higher is required. Current version: $(node --version)"
    exit 1
fi

echo "✅ Node.js version: $(node --version)"

# Check if package.json exists
if [ ! -f "package.json" ]; then
    echo "❌ package.json not found. Please make sure you're in the correct directory."
    exit 1
fi

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install --production
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install dependencies."
        exit 1
    fi
    echo "✅ Dependencies installed successfully."
else
    echo "✅ Dependencies already installed."
fi

# Check if env-production.js exists
if [ ! -f "env-production.js" ]; then
    echo "❌ env-production.js not found. Please check your configuration."
    exit 1
fi

echo "✅ Configuration files found."

# Start the application
echo "🚀 Starting the application..."
echo "📍 Health check: https://elaraix.com/exam/health"
echo "📍 Main app: https://elaraix.com/exam/"
echo ""
echo "Press Ctrl+C to stop the application."
echo ""

node server.js 