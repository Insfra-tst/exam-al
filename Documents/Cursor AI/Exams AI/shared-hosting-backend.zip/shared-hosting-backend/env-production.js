// Production environment configuration for elaraix.com
module.exports = {
    // Database Configuration
    DB_HOST: 'localhost',
    DB_USER: 'iextqmxf_exams',
    DB_PASSWORD: 'D#3ItY3za(BZ',
    DB_NAME: 'iextqmxf_exams',
    DB_PORT: 3306,

    // OpenAI Configuration
    OPENAI_API_KEY: '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',

    // JWT Configuration
    JWT_SECRET: 'exam_analyzer_jwt_secret_key_2024_secure_and_random',

    // Server Configuration
    PORT: 3000,
    NODE_ENV: 'production',
    HOST: '0.0.0.0',

    // Application Configuration
    APP_URL: 'https://elaraix.com/exam',
    BASE_PATH: '/exam',

    // Email Configuration (optional)
    EMAIL_HOST: 'smtp.gmail.com',
    EMAIL_PORT: 587,
    EMAIL_USER: 'your_email@gmail.com',
    EMAIL_PASS: 'your_email_password'
}; 